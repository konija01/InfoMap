export type SegmentType = 'background' | 'all' | 'spd' | 'qtv' | 'ild' | 'txt';
