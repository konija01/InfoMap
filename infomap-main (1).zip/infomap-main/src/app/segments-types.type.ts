import {SegmentTypePixels} from "./segment-type-pixels";

export type SegmentsTypes = { [key: string]: SegmentTypePixels };
