import {Component, OnInit} from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {DecimalPipe, KeyValue, KeyValuePipe, NgClass, NgForOf, NgIf, NgTemplateOutlet} from "@angular/common";
import {MatButtonModule} from "@angular/material/button";
import {MatDividerModule} from "@angular/material/divider";
import {SegmentType} from "./segment-type.type";
import {Rectangle} from "./rectangle.type";
import {SegmentTypePixels} from "./segment-type-pixels";
import {SegmentsTypes} from "./segments-types.type";
import {ImagePixel} from "./image-pixel.type";
import {MatButtonToggleModule} from "@angular/material/button-toggle";
// @ts-ignore
import {Sobel} from 'sobel/sobel.js';
import {MatIconModule} from "@angular/material/icon";


type Image = {
  width: number;
  height: number;
  file?: File;
  image?: Image;
  canvas?: HTMLCanvasElement;
  canvasContext?: CanvasRenderingContext2D;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    MatButtonModule,
    MatDividerModule,
    MatIconModule,
    MatButtonToggleModule,
    RouterOutlet,
    NgForOf,
    NgIf,
    KeyValuePipe,
    NgClass,
    DecimalPipe,
    NgTemplateOutlet,
  ],
  template: `
    <div
      style="width: 100%; margin: 0 auto; padding-top: 30px; padding-bottom: 30px; display: flex; flex-direction: row;">
      <div style="flex: 2; padding: 0 4em;">

        <div style="margin: 0 auto 2em;">
          <p>
            <strong style="text-transform: uppercase;">1. Nahrajte svoju mapu</strong>
          </p>
          <p>
            <small>Vyberte súbor mapy pripravený podľa inštrukcií v manuále.</small>
          </p>
          <div style="margin: 1em auto; text-align: center;">
            <button (click)="fileInput.click()" mat-flat-button color="primary">
              nahrať mapu
            </button>
          </div>
          <input #fileInput
                 style="text-align: center;"
                 hidden type="file"
                 class="file-upload"
                 accept="image/jpeg"
                 (change)="fileSelected($event)">
        </div>

        <section style="margin: 2em auto;">
          <div style="margin: 1em auto;">
            <p style="text-align: left;">
              <strong style="text-transform: uppercase;">2. Šírka štetca</strong>
            </p>
            <p>
              <small>Vyberte veľkosť výberu pixelov v mriežke.</small>
            </p>
            <div style="text-align: center; margin-top: 1em;">
              <mat-button-toggle-group [hideSingleSelectionIndicator]="true" style="vertical-align: middle;">
                <mat-button-toggle [value]="0" [checked]="turbo === 0" (click)="turbo = 0">
                  <small style="font-size: 0.7em; vertical-align: initial;">⬤</small>
                </mat-button-toggle>
                <mat-button-toggle [value]="1" [checked]="turbo === 1" (click)="turbo = 1">
                  <small style="font-size: 0.9em; vertical-align: initial;">⬤</small>
                </mat-button-toggle>
                <mat-button-toggle [value]="2" [checked]="turbo === 2" (click)="turbo = 2">
                  <small style="font-size: 1.1em; vertical-align: initial;">⬤</small>
                </mat-button-toggle>
                <mat-button-toggle [value]="3" [checked]="turbo === 3" (click)="turbo = 3">
                  <small style="font-size: 1.3em; vertical-align: initial;">⬤</small>
                </mat-button-toggle>
                <mat-button-toggle [value]="4" [checked]="turbo === 4" (click)="turbo = 4">
                  <small style="font-size: 1.5em; vertical-align: initial;">⬤</small>
                </mat-button-toggle>
                <mat-button-toggle [value]="5" [checked]="turbo === 5" (click)="turbo = 5">
                  <small style="font-size: 1.7em; vertical-align: initial;">⬤</small>
                </mat-button-toggle>
              </mat-button-toggle-group>
            </div>
          </div>
        </section>

        <section style="margin: 2em auto;">
          <p>
            <strong style="text-transform: uppercase;">3. Vyberte komponenty</strong>
          </p>
          <p>
            <small>Označte pixely v mriežke odpovedajúce komponentu.</small>
          </p>
          <ng-template ngFor let-segmentType [ngForOf]="segmentsTypes|keyvalue:fakeOnCompare">
            <div style="margin: 1em auto; text-align: center;" *ngIf="segmentType.value.showInMenu">
              <ng-template #square>
                <strong *ngIf="segmentType.value.segmentType !== 'background'"
                        [style.color]="removeRgbaAlpha(segmentType.value.color)">
                  ⬤
                </strong>
                <strong *ngIf="segmentType.value.segmentType === 'background'" [style.color]="'black'">
                  ◯
                </strong>
                &nbsp;{{ segmentType.value.name }}
              </ng-template>
              <button *ngIf="currentSegmentType === segmentType.value.segmentType"
                      (click)="currentSegmentType = segmentType.value.segmentType"
                      style="color: #FFFFFF;"
                      [style.background-color]="removeRgbaAlpha(segmentType.value.color)"
                      mat-flat-button>
                <ng-container *ngTemplateOutlet="square"></ng-container>
              </button>
              <button *ngIf="currentSegmentType !== segmentType.value.segmentType"
                      (click)="currentSegmentType = segmentType.value.segmentType"
                      style="background-color: #FFFFFF;"
                      [style.color]="removeRgbaAlpha(segmentType.value.color)"
                      mat-stroked-button>
                <ng-container *ngTemplateOutlet="square"></ng-container>
              </button>
            </div>
          </ng-template>
        </section>

        <section style="margin: 2em auto 2em;">
          <div style="margin: 1em auto; text-align: center;">
            <button *ngIf="currentSegmentType === segmentsTypes['background'].segmentType"
                    (click)="currentSegmentType = segmentsTypes['background'].segmentType"
                    mat-flat-button
                    style="background-color: #666666; color: #FFFFFF;">
              ručné odznačenie
            </button>
            <button *ngIf="currentSegmentType !== segmentsTypes['background'].segmentType"
                    (click)="currentSegmentType = segmentsTypes['background'].segmentType"
                    mat-stroked-button
                    style="color: #666666; background-color: #FFFFFF;">
              ručné odznačenie
            </button>
          </div>
          <div style="margin: 1em auto; text-align: center;">
            <button (click)="imageShow()" mat-flat-button style="color: #FFFFFF; background-color: #666666;">
              odznačiť všetko
            </button>
          </div>
        </section>

        <section style="margin: 2em auto;">
          <p style="text-align: left;">
            <strong style="text-transform: uppercase;">4. Spustite hodnotenie</strong>
          </p>
          <p>
            <small>
              Kliknutím na tlačidlo spustiť začne automatický výpočet.
            </small>
          </p>
          <div style="margin: 1em auto; text-align: center;">
            <button mat-flat-button (click)="updatePixelCount()" color="warn">
              spustiť
            </button>
          </div>
        </section>

      </div>

      <div style="flex: 6;">
        <div style="border: 30px solid black; width: 80%; margin: auto; position: relative;">
          <div id="image_div"
               [style.display]="image ? 'block' : 'background'"
               style="position: relative; top: 0; left: 0; width: 100%; z-index: 100;"></div>
          <div *ngIf="!image" style="padding: 2em; text-align: center;">
            <p>Nebyl vybrán vstupní soubor.</p>
          </div>
          <ng-template [ngIf]="image">
            <div *ngFor="let segment of rectangles; trackBy:identifySegment"
                 class="segment"
                 style="border: 1px solid rgba(120,120,120,.1); margin:0; padding:0; position: absolute; z-index: 100;"
                 [style.width]="((rectangleSize / image.width) * 100) + '%'"
                 [style.height]="((rectangleSize / image.height) * 100) + '%'"
                 [style.top]="((segment.rowNumber * (rectangleSize / image.height)) * 100) + '%'"
                 [style.left]="((segment.columnNumber * (rectangleSize / image.width)) * 100) + '%'"
                 [style.background-color]="segment.color ?? 'transparent'">
            </div>
          </ng-template>
        </div>
      </div>

    </div>

    <div
      style="width: 100%; margin: 0 auto; padding-top: 30px; padding-bottom: 30px; display: flex; flex-direction: row;">
      <div style="width: 100%; text-align: center; color: red;" *ngIf="(!image || selecting) && !loading">
        <p><strong>Vyberte soubor a vyznačte příslušné oblasti.</strong></p>
      </div>
      <div style="width: 100%; text-align: center; color: red;" *ngIf="loading">
        <p><strong>Probíhá výpočet...</strong></p>
      </div>
      <ng-template [ngIf]="image && !selecting && !loading">

        <div style="width: 100%;">
          <div style="margin-bottom: 1em;">
            <table style="width: 90%; margin: auto; border: 2px solid grey; text-align: center;">
              <tr>
                <th>komponent</th>
                <th>plocha pokrytia</th>
                <th>vizuálna príťažlivosť</th>
                <th>farebnosť</th>
                <th>grafická náplň</th>
                <th>IndicatorScore</th>
              </tr>
              <ng-template ngFor let-segmentType [ngForOf]="segmentsTypes|keyvalue:fakeOnCompare">
                <tr *ngIf="segmentType.value.showInTable">
                  <td>
                    <strong>{{ segmentType.value.name }}</strong>
                  </td>
                  <td>{{ segmentType.value.areaCoverage|number: '1.0-3' }}</td>
                  <td>{{ segmentType.value.visualAttractiveness|number: '1.0-3' }}</td>
                  <td>{{ segmentType.value.colorfulness|number: '1.0-3' }}</td>
                  <td>{{ segmentType.value.graphicLoad|number: '1.0-3' }}</td>
                  <td>{{ segmentType.value.indicatorScore|number: '1.0-3' }}</td>
                </tr>
              </ng-template>
            </table>
          </div>

          <div>
            <table style="width: 90%; margin: auto; border: 2px solid grey; text-align: center;">
              <tr>
                <th>LayoutScore</th>
              </tr>
              <tr>
                <td>
                  <strong>
                    {{ ((segmentsTypes['spd'].layoutScore + segmentsTypes['qtv'].layoutScore + segmentsTypes['ild'].layoutScore + segmentsTypes['txt'].layoutScore) / 1.5)|number: '1.0-3' }}
                  </strong>
                </td>
              </tr>
            </table>
          </div>
        </div>

      </ng-template>

    </div>

    <div style="width: 30%; margin: 0 auto; padding-top: 30px; padding-bottom: 30px; display: none;">
      <canvas id="sobel_canvas" style="width: 100%;"></canvas>
    </div>

  `,
  styles: [`
    mat-toggle-button-group, button {
      width: 100%;
      margin: auto;
    }

    p {
      margin-top: .5em;
      margin-bottom: .5em;
    }
  `],
})
export class AppComponent implements OnInit {
  Math = Math;
  rectangleSize: number = 20;

  selecting = true;

  currentSegmentType: SegmentType = 'spd';

  forcedImageLongerSize = 2450;

  mouseDown = false;

  rectangles: Rectangle[] = [];

  image?: Image;

  canvas?: HTMLCanvasElement;
  canvasContext?: CanvasRenderingContext2D | null;

  sobelCanvas?: HTMLCanvasElement;
  sobelCanvasContext?: CanvasRenderingContext2D | null;

  turbo: number = 0;

  segmentsTypes: SegmentsTypes = {
    spd: new SegmentTypePixels('priestorový', 'spd', .25, 'rgba(240,80,80,.75)', 1),
    qtv: new SegmentTypePixels('dátová vizualizácia', 'qtv', .5, 'rgba(80,240,80,.75)', 2),
    ild: new SegmentTypePixels('ilustratívny', 'ild', .5, 'rgba(80,80,240,.75)', 3),
    txt: new SegmentTypePixels('textový', 'txt', .25, 'rgba(239,161,17,0.69)', 4),
    background: new SegmentTypePixels('background', 'background', 0, 'transparent', 5, false, false),
  };

  get loading(): boolean {
    return this.segmentsTypes['spd'].loading
      || this.segmentsTypes['qtv'].loading
      || this.segmentsTypes['ild'].loading
      || this.segmentsTypes['txt'].loading;
  }

  ngOnInit() {
    const events: { [key: string]: boolean } = {mousedown: true, touchstart: true, mouseup: false, touchend: false};
    for (let key of Object.keys(events)) {
      window.addEventListener(key, async () => {
        this.mouseDown = events[key];
      });
    }
  }

  updatePixelCount(): void {
    for (let key of Object.keys(this.segmentsTypes)) {
      this.segmentsTypes[key].loading = true;
    }
    this.selecting = false;

    if (typeof Worker !== 'undefined') {
      const worker = new Worker(new URL('./pixel-processing.worker', import.meta.url));
      worker.onmessage = ({data}) => {
        const pixelsByTypes: {
          [key: string]: { pixels: ImagePixel[]; sobelPixelsIntensitiesSum: number; }
        } = data.pixelsByTypes;

        console.log("Updating computations...");

        for (const segmentTypeKey in this.segmentsTypes) {
          console.log('Start:', segmentTypeKey);
          if (segmentTypeKey === 'background') {
            continue;
          }
          let surroundingPixels: ImagePixel[] = [];
          for (let key of Object.keys(this.segmentsTypes)) {
            if (key !== segmentTypeKey) {
              const time = new Date();
              surroundingPixels = surroundingPixels.concat(pixelsByTypes[key].pixels);
              const time2 = new Date();
              const dateDiff = time2.getTime() - time.getTime();
              console.log('Segment processing took', dateDiff / 1000, 'seconds.');
            }
          }
          this.segmentsTypes[segmentTypeKey].updateComputations(
            pixelsByTypes[segmentTypeKey].pixels,
            surroundingPixels,
            pixelsByTypes[segmentTypeKey].sobelPixelsIntensitiesSum,
          );
          console.log('End:', segmentTypeKey);
        }
        console.log("Done.");

      };
      worker.postMessage({segments: this.rectangles});
    } else {
      alert("Web worker can't be started. Try another browser.");
    }
  }

  imageShow(): void {
    if (this.image) {
      this.rectangles = [];
      const segmentsInRow = (this.image.height / this.rectangleSize);
      const seriesId = Math.floor(Math.random() * 1000);
      for (let rowNumber = 0; rowNumber < (this.image.height / this.rectangleSize); rowNumber++) {
        for (let columnNumber = 0; columnNumber < (this.image.width / this.rectangleSize); columnNumber++) {
          const imageData = this.getImageData(this.canvasContext, columnNumber, rowNumber);
          const pixels: ImagePixel[] = [];
          if (imageData) {
            for (let i = 0; i < (imageData?.data.length ?? 0); i += 4) {
              pixels.push({r: imageData.data[i], g: imageData.data[i + 1], b: imageData.data[i + 2]});
            }
          }

          let sobelPixelsIntensitiesSum: number = 0;
          const sobelImageData = this.getImageData(this.sobelCanvasContext, columnNumber, rowNumber);
          if (sobelImageData) {
            for (let i = 0; i < (sobelImageData?.data.length ?? 0); i += 4) {
              sobelPixelsIntensitiesSum += (
                ((sobelImageData.data[i] + sobelImageData.data[i + 1] + sobelImageData.data[i + 2]) / 3) / 255 * 100
              );
            }
          }

          this.rectangles.push({
            id: '' + seriesId + ((rowNumber * segmentsInRow) + columnNumber),
            rowNumber,
            columnNumber,
            pixels,
            sobelPixelsIntensitiesSum,
          });
        }
      }
      setTimeout(() => {
        const segments = document.querySelectorAll('.segment');
        for (let index = 0; index < segments.length; index++) {
          const element = segments[index];
          element.addEventListener('contextmenu', event => event.preventDefault());
          for (let event of ['mouseover', 'mouseenter', 'mousedown', 'click']) {
            element.addEventListener(event, async () => {
              this.segmentClicked(index, ['mousedown', 'click'].includes(event));
            });
          }
        }
      }, 500);
    }
  }

  getImageData(
    canvasContext: CanvasRenderingContext2D | null | undefined,
    columnNumber: number,
    rowNumber: number,
  ) {
    return canvasContext?.getImageData(
      columnNumber * this.rectangleSize,
      rowNumber * this.rectangleSize,
      Math.min(this.rectangleSize, ((this.image?.width ?? 0) - (columnNumber * this.rectangleSize))),
      Math.min(this.rectangleSize, ((this.image?.height ?? 0) - (rowNumber * this.rectangleSize))),
    );
  }

  segmentClicked(index: number, forced: boolean = false): void {
    const segment = this.rectangles[index];
    if ((this.mouseDown || forced) && segment.segmentType !== this.currentSegmentType) {
      segment.color = this.segmentsTypes[this.currentSegmentType].color;
      segment.segmentType = this.currentSegmentType;
    }
    if (this.turbo > 0) {
      const size = this.turbo;
      const neighbors = this.rectangles.filter(s => {
        const verticalDiff = Math.abs(s.rowNumber - segment.rowNumber);
        const horizontalDiff = Math.abs(s.columnNumber - segment.columnNumber);

        return (verticalDiff <= size && horizontalDiff <= size && ((verticalDiff + horizontalDiff) / 2) <= (size - size / 4));
      });
      for (let s of neighbors) {
        if ((this.mouseDown || forced) && s.segmentType !== this.currentSegmentType) {
          s.color = this.segmentsTypes[this.currentSegmentType].color;
          s.segmentType = this.currentSegmentType;
        }
      }
    }
  }

  public fileSelected(event: Event) {
    const target = event.target as HTMLInputElement;
    const files = target.files ?? [];
    const file: File = files[0];
    if (file) {
      const reader = new FileReader();
      const that = this;
      reader.onload = function (e) {
        const img = new Image();
        let originalWidth = 0;
        let originalHeight = 0;
        img.onload = function (event) {
          that.canvas = document.createElement('canvas');
          that.canvasContext = that.canvas.getContext('2d', {willReadFrequently: true});
          if (!that.canvasContext) {
            return;
          }
          const newImageSize = that.getForcedImageSize(img.width, img.height);
          that.canvas.width = newImageSize.width;
          that.canvas.height = newImageSize.height;
          that.canvasContext.drawImage(img, 0, 0, that.canvas.width, that.canvas.height);
          that.image = {
            file: file,
            image: img,
            width: that.canvas.width,
            height: that.canvas.height,
            canvas: that.canvas,
            canvasContext: that.canvasContext,
          };
          that.drawSobelImage(img);
          that.imageShow();
        }

        img.src = <string>e.target?.result;

        const image = document.createElement("img");
        image.src = <string>e.target?.result;
        image.style.width = '100%';
        const imageDiv = document.querySelector('#image_div');
        if (imageDiv) {
          imageDiv.innerHTML = '';
          imageDiv?.appendChild(image);
        }
      }
      reader.readAsDataURL(file);
    }
  }

  drawSobelImage(image: HTMLImageElement) {
    this.sobelCanvas = <HTMLCanvasElement>document.getElementById('sobel_canvas');
    this.sobelCanvasContext = this.sobelCanvas?.getContext('2d', {willReadFrequently: true});
    if (!this.sobelCanvas || !this.sobelCanvasContext) {
      alert('Problem with canvas!');
      return;
    }

    const newImageSize = this.getForcedImageSize(image.width, image.height);
    this.sobelCanvas.width = newImageSize.width;
    this.sobelCanvas.height = newImageSize.height;

    this.sobelCanvasContext.drawImage(image, 0, 0, this.sobelCanvas.width, this.sobelCanvas.height);
    const imageData = this.sobelCanvasContext.getImageData(0, 0, this.sobelCanvas.width, this.sobelCanvas.height);
    const sobelData = Sobel(imageData);
    const sobelImageData = sobelData.toImageData();
    this.sobelCanvasContext.putImageData(sobelImageData, 0, 0);
  }

  identifySegment(index: number, item: Rectangle) {
    return item.id;
  }

  protected fakeOnCompare(
    _left: KeyValue<string, SegmentTypePixels>,
    _right: KeyValue<string, SegmentTypePixels>,
  ): number {
    return (_left.value.order ?? 0) - (_right.value.order ?? 0);
  }

  protected getForcedImageSize(width: number, height: number): { width: number, height: number } {
    if (width >= height) {
      return {
        width: this.forcedImageLongerSize,
        height: height / width * this.forcedImageLongerSize,
      };
    } else {
      return {
        height: this.forcedImageLongerSize,
        width: width / height * this.forcedImageLongerSize,
      };
    }
  }

  removeRgbaAlpha(color: string): string {
    return color.replace(/[\d.]+\)$/g, '1)');
  }
}
