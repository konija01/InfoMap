export type ImagePixel = {
  r: number;
  g: number;
  b: number;
}
